package com.hsc.security.entity;


import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;
import java.util.Objects;

public class Student {
    private Integer studentId;

    @NotBlank(message = "Student name cannot be left blank")
    private String studentName;

    @NotBlank(message = "Email cannot be left blank")
    @Email(message = "Email must be well formed")
    private String studentEmail;

    @NotNull(message = "list cannot be empty")
    @Valid
    List<Package> listPkg;

    public List<Package> getListPkg() {
        return listPkg;
    }

    public void setListPkg(List<Package> listPkg) {
        this.listPkg = listPkg;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public static class Package{

        @NotNull
        @Digits(integer = 10, fraction = 0, message = "should be a number")
        private long packageId;
        @NotBlank(message = "package is emoty")
        private String packageName;

        public long getPackageId() {
            return packageId;
        }

        public void setPackageId(long packageId) {
            this.packageId = packageId;
        }

        public String getPackageName() {
            return packageName;
        }

        public void setPackageName(String packageName) {
            this.packageName = packageName;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Package)) return false;
            Package aPackage = (Package) o;
            return getPackageId() == aPackage.getPackageId() &&
                    getPackageName().equals(aPackage.getPackageName());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getPackageId(), getPackageName());
        }
    }
}
