package com.hsc.security.controller;


import com.hsc.security.entity.Student;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.executable.ExecutableValidator;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("api/v1/students")
@Validated
public class StudentController {

    @GetMapping(path = "{studentId}")
    public Object getStudent(@Valid @RequestBody Student student, Errors errors) {

        System.out.println("this is it");
         return student;
    }

    @GetMapping(path = "a/{studentId}")
    public Object getData(@RequestBody @Valid Student student, Errors errors) throws Exception {

        return student;
    }
}
